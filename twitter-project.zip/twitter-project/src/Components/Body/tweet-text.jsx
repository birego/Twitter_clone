export default function TweetText(){
    return(
        <div className="tweet-text">
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. In aperiam culpa nostrum nisi ratione dolorem dolorum eum illo nihil dignissimos. Modi tempora id itaque odio fuga alias sequi exercitationem cumque.</p>
        </div>
    )
}