export default function TweetTitle(){
    return(
        <div className="tweet-title">
            <h3>The New-York Times</h3>
        </div>
    )
}