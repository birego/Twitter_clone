export default function Tweeti(){
    return ( <div className="tweet">
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio minima quasi modi, cum quas voluptatibus dignissimos qui perspiciatis architecto facere repellat enim laborum amet, dolores voluptas cumque dolorum praesentium neque?
    </div> )
}