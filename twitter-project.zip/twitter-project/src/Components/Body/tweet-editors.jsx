import Avatar  from "./avatar.jsx"
import  Form from "./tweet-editor-form.jsx"
export default function TwittEed(){
    return (
        <div className="tweet-editor">
            <Avatar/>
            <Form/>
        </div>
    )
}