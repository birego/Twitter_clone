
export default function TweetTitleEditor(){
    return(
        <div>
            <h3 className="twitter-title-author">Twitter</h3>
        </div>
    )
}