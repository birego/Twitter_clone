import Tweeti from "./tweet"
import Tweet2 from "./tweet2.jsx"
import Tweet3 from "./tweet3"
export default function Tweet(){
    return(
        <div className="tweetS">
            <Tweeti/>
            <Tweet2/>
            <Tweet3/>
        </div>
    )
}