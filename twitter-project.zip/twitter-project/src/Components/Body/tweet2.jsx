import TwitteAvatar from "./tweetavatar"
import TwitteContent from "./tweetcontent"
export default function Tweet2(){
    return(
      <div className="tweet">
        <TwitteAvatar/>
        <TwitteContent/>
      </div>  
    )
}