
import TwitteContent from "./tweetcontent"
export default function Tweet3(){
    return(
      <div className="tweet">
        
      </div>  
    )
}