import TweetImg from "../../assets/tweet.jpeg"

export default function TweetImage(){
    return(
        <div className="tweet-image">
            <img src={TweetImg}/>
        </div>
    )
}