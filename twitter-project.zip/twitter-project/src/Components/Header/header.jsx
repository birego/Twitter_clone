import Home from "./home";
import Toptwitte from "./top-tweets"

export default function Header(){
    return (<div className="header">
        <Home/>
        <Toptwitte/>
    </div>)

}